from fastapi import FastAPI
from app.database import Base, engine

# Import routers
from app.routers import auth, item_router, swap, admin

app = FastAPI()

# Create tables
Base.metadata.create_all(bind=engine)

# Include routers

app.include_router(auth.router, prefix="/auth", tags=["Auth"])

app.include_router(item_router.router, prefix="/items", tags=["Items"])

app.include_router(swap.router, prefix="/swaps", tags=["Swaps"])

app.include_router(admin.router, prefix="/admin", tags=["Admin"])
