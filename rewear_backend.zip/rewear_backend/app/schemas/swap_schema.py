from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class SwapCreate(BaseModel):
    requested_item_id: int
    offered_item_id: Optional[int] = None
    swap_type: str  # "direct" or "points"

class SwapAccept(BaseModel):
    swap_id: int
    accept: bool

class SwapOut(BaseModel):
    id: int
    requested_item_id: int
    offered_item_id: Optional[int]
    swap_type: str
    status: str
    created_at: datetime

    class Config:
        orm_mode = True
