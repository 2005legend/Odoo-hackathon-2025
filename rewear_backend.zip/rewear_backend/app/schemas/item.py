from typing import List
from pydantic import BaseModel

class ItemCreate(BaseModel):
    title: str
    description: str
    category: str
    type: str
    size: str
    condition: str
    tags: List[str]
    points_value: int

class ItemOut(ItemCreate):
    id: int
    images: List[str]
    status: str

    model_config = {
        "from_attributes": True
    }
