from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.schemas import user as user_schemas
from app.models import user as user_models
from app.utils import auth as auth_utils

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/register", response_model=user_schemas.UserResponse)
def register(user: user_schemas.UserCreate, db: Session = Depends(get_db)):
    existing = db.query(user_models.User).filter(
    user_models.User.email == user.email
    ).first()

    if existing:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    # Hash the password before storing
    hashed = auth_utils.hash_password(user.password)

    # Create a new User model instance
    db_user = user_models.User(
        email=user.email,
        hashed_password=hashed,
        name=user.name
    )

    # Save to database
    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    # Return the created user (excluding password)
    return db_user

@router.post("/login")
def login(user: user_schemas.UserLogin, db: Session = Depends(get_db)):
    # Find user in DB by email
    db_user = db.query(user_models.User).filter(
        user_models.User.email == user.email
    ).first()

    # If not found or password is incorrect → error
    if not db_user or not auth_utils.verify_password(user.password, db_user.hashed_password):
        raise HTTPException(
            status_code=401,
            detail="Invalid credentials"
        )

    # Create JWT token
    token = auth_utils.create_access_token({"sub": str(db_user.id)})

    # Return token and basic info
    return {
        "access_token": token,
        "token_type": "bearer",
        "user_id": db_user.id,
        "name": db_user.name
    }


from app.deps import user as user_deps

@router.get("/me", response_model=user_schemas.UserResponse)
def get_me(current_user: user_models.User = Depends(user_deps.get_current_user)):
    return current_user
