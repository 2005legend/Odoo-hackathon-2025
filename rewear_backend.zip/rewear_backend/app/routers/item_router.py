from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, Form
from sqlalchemy.orm import Session
from app.database import get_db
from schemas.item import ItemCreate, ItemOut
from models.item import Item
from typing import List
import os, shutil, uuid

router = APIRouter()
UPLOAD_DIR = "uploads"

# ✅ POST /upload-image - Standalone image upload (optional)
@router.post("/upload-image/")
def upload_image(file: UploadFile = File(...)):
    filename = f"{uuid.uuid4().hex}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return {"filename": filename}

# ✅ POST /items - Create item without image
@router.post("/items/", response_model=ItemOut)
def create_item(item: ItemCreate, db: Session = Depends(get_db)):
    new_item = Item(**item.dict(), user_id=1, images=[], status="available")
    db.add(new_item)
    db.commit()
    db.refresh(new_item)
    return new_item

# ✅ GET /items - Fetch all items
@router.get("/items/", response_model=List[ItemOut])
def get_items(db: Session = Depends(get_db)):
    items = db.query(Item).all()
    return items

# ✅ POST /items/with-image - Create item with image upload
@router.post("/items/with-image", response_model=ItemOut)
def create_item_with_image(
    title: str = Form(...),
    description: str = Form(...),
    category: str = Form(...),
    type: str = Form(...),
    size: str = Form(...),
    condition: str = Form(...),
    tags: str = Form(...),  # e.g. "blue,winter"
    points_value: int = Form(...),
    image: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    # Save image to disk
    filename = f"{uuid.uuid4().hex}_{image.filename}"
    file_path = os.path.join(UPLOAD_DIR, filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(image.file, buffer)

    # Convert tags string to list
    tag_list = [tag.strip() for tag in tags.split(",")]

    # Create item
    new_item = Item(
        title=title,
        description=description,
        category=category,
        type=type,
        size=size,
        condition=condition,
        tags=tag_list,
        points_value=points_value,
        user_id=1,
        images=[filename],
        status="available"
    )

    db.add(new_item)
    db.commit()
    db.refresh(new_item)
    return new_item
