from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models.item import Item
from typing import List
from app.models.user import User

router = APIRouter(prefix="/admin", tags=["Admin"])

@router.get("/items/pending")
def get_pending_items(db: Session = Depends(get_db)):
    pending_items = db.query(Item).filter(Item.status == "pending").all()
    return pending_items

@router.post("/items/approve")
def approve_item(item_id: int, approve: bool, db: Session = Depends(get_db)):
    item = db.query(Item).filter(Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")

    item.status = "available" if approve else "rejected"
    db.commit()
    db.refresh(item)
    return {"message": f"Item {'approved' if approve else 'rejected'} successfully", "item_id": item.id}

