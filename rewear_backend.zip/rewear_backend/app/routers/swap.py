from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models.swap import SwapRequest
from schemas.swap_schema import SwapCreate, SwapAccept, SwapOut
from models.item import Item
from models.users import User
from core.dependencies import get_current_user

router = APIRouter(prefix="/swap", tags=["Swap"])

@router.post("/request", response_model=SwapOut)
def create_swap(request: SwapCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    item = db.query(Item).filter(Item.id == request.requested_item_id).first()
    if not item or item.user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Invalid item")
    swap = SwapRequest(
        requester_id=current_user.id,
        item_owner_id=item.user_id,
        requested_item_id=request.requested_item_id,
        offered_item_id=request.offered_item_id,
        swap_type=request.swap_type
    )
    db.add(swap)
    db.commit()
    db.refresh(swap)
    return swap

@router.post("/accept", response_model=SwapOut)
def accept_swap(request: SwapAccept, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    swap = db.query(SwapRequest).filter(SwapRequest.id == request.swap_id).first()
    if not swap or swap.item_owner_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not allowed")
    swap.status = "accepted" if request.accept else "rejected"
    db.commit()
    db.refresh(swap)
    return swap

@router.get("/my-swaps", response_model=list[SwapOut])
def get_my_swaps(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    swaps = db.query(SwapRequest).filter(SwapRequest.requester_id == current_user.id).all()
    return swaps
