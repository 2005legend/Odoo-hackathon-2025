from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from database import Base
from datetime import datetime

class SwapRequest(Base):
    __tablename__ = "swap_requests"

    id = Column(Integer, primary_key=True, index=True)
    requester_id = Column(Integer, ForeignKey("users.id"))
    item_owner_id = Column(Integer, ForeignKey("users.id"))
    requested_item_id = Column(Integer, ForeignKey("items.id"))
    offered_item_id = Column(Integer, ForeignKey("items.id"), nullable=True)
    swap_type = Column(String)
    status = Column(String, default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
