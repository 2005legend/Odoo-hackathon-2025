from sqlalchemy import Column, Integer, String, Text, ForeignKey, JSON
from sqlalchemy.sql import func
from sqlalchemy.types import DateTime
from database import Base

class Item(Base):
    __tablename__ = "items"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String)
    description = Column(Text)
    category = Column(String)
    type = Column(String)
    size = Column(String)
    condition = Column(String)
    tags = Column(JSON)
    images = Column(JSON)
    status = Column(String, default="available")
    points_value = Column(Integer, default=10)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
